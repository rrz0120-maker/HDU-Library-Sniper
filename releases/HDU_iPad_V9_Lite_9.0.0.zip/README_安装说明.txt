HDU iPad V9 Lite 9.0.0 安装包
文件：HDU_iPad_V9_Lite.user.js
版本来源：https://github.com/rrz0120-maker/HDU-Library-Sniper/commit/cafeb1c3764765e2feff948ebc62641e4e693b49

使用方法：
1. 在iPad的“文件”App中解压此ZIP。
2. 将HDU_iPad_V9_Lite.user.js保存到Safari Userscripts扩展设置的脚本目录，并开启扩展。
3. 停用所有旧版HDU预约脚本，关闭旧标签页，在Safari重新打开官网并登录。
4. 确认右下角出现“162预约”，设置时间并启动。
5. 整点抢座应保持Safari前台及屏幕常亮。

注意：本版仅通过模拟测试；真实iPad/馆方20:00尚未验收。
